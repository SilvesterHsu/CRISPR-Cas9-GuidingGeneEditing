<template>
	<div id="app">
		<div class="page">
			<div class="page-title">Introduction</div>
			<div class="content-area">
				<div id="h1">In GGE, we implement this efficiency predicting model via transfer learning for gene knock-out in Danio rerio (danRer11/GRCz11) using CRISPR/Cas9. 
				Users can input the genomic location (usually a not more than 300 bases wide window around a TSS) to find the efficiency prediction and its rank for each guide in this zone. 
				This web application also offers visualization on the results and the results can be download as csv files. 
				Have a try and enjoy GGE!
				</div>
				<div id="h2">CRISPR/Cas9 scoring</div>
				<div id="normal-text">
				<strong>Bad GC: </strong><40 or >70<br>
				<strong>4nt self-complementary stem found: </strong>1 for each<br>
				<strong>Efficiency: </strong>efficiency value comes from our prediction algorithm * 100<br>
				<strong>CRISPR color thresholds: </strong>Dark Color >= 59.85 >= Normal Color >= 42.99 >= Light Color<br><br>
				MM0 = 0 mismatches, MM1 = 1 mismatch, MM2 = 2 mismatches, MM3 = 3 mismatches
				</div>
			</div>
		</div>
	</div>
</template>

<script>
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  text-align: -webkit-center;
  color: #2c3e50;
}

.page{
	display: flex;
	display: -webkit-flex;
	flex-direction: column;
	width: 100%;
}

.page-title{
	font-size: 55px;
	margin-top: 200px;
	margin-bottom: 70px;
	color: rgba(44,62,80,1);
	
}

.content-area{
	width: 55%;
	margin-left: 20%;
	margin-right: 25%;
	border-color: rgba(44,62,80,0.8);
	border-style: dashed;
	border-width: thin;
	border-radius: 50px;
	height: 520px;
	text-align: left;
	text-align: -webkit-left;
	padding-left: 50px;
	padding-right: 50px;
}

#h1{
	font-size: 25px;
	margin-top: 50px;
	margin-bottom: 20px;
	color: rgba(44,62,80,0.8);
}

#h2{
	font-size: 25px;
	font-weight: bold;
	margin-top: 30px;
	margin-bottom: 20px;
	color: rgba(44,62,80,0.8);
}

#normal-text{
	font-size: 20px;
	line-height: 30px;
}

</style>
