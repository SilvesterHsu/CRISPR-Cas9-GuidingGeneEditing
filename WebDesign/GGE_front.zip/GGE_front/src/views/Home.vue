<template>
  <div id="app">
    <div class="page-home">
		<div class="logo"></div>
		<div class="title">GGE <strong>GGE</strong></div>
		<div class="input-area">
			<div class="input-label">Target:</div>
			<div class="input-box">
				<input class="gene" v-model="gene" placeholder="Genomic coordinates, e.g. chr11:37719830-37720130">
				<button class="clear-input" @click="clear">reset</button>
			</div>
		</div>
		<div class="fixed-area">
			<div class="species">In:<br>Danio rerio (danRer11/GRCz11)</div>
			<div class="method">Using:<br>CRISPR/Cas9</div>
			<div class="knock">For:<br>knock-out</div>
		</div>
		<div class="submit-area">
			<button class="submit-button" @click="submit">Find Target Sites!</button>
		</div>
		<div class="alert" v-show="isShow">Gene does not exist. <br>
		Please input genomic coordinates.<br>
		It should be a no more than 300 bases window around a TSS,<br>
		e.g. chr13:39276927-39277227
		</div>
    </div>
  </div>
</template>

<script>
//import HelloWorld from './components/HelloWorld.vue'
import axios from 'axios';

export default {
  name: 'home',
  components: {},
  data() {
	  return {
		  gene: '',
		  isShow: false,
		  pass: false,
		  arr: ['a','b','c']
	  }
	  
  },
  methods: {
	  async submit(){
		  var reg = /^chr\d{1,2}:\d{5,20}-\d{5,20}$/
		  
		  if (reg.test(this.gene)){
		  		this.isShow = false;
		  		//console.log(this.isShow);
				let thisLoc = window.location.href.split('?')[0].replace("home","test");
				await axios.post(thisLoc + '/'+ this.gene.replace(":","_"))
				.then((res)=>{
				    if (res.status===200){
						if (res.data.msg==='666') {
							let routeUrl = this.$router.resolve({
								path: '/results',
								query: {gene: this.gene}
							});
							window.open(routeUrl.href, '_blank');
						}
						else
						{
							this.isShow = true;
						}
					} else{
						this.isShow = true;
					}
				});  
		  } else{
		  		this.isShow = true;
		  		//console.log(this.isShow);
		  } 
	  },
	  clear(){
		  this.gene = '';
	  }
  }
  
  
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  text-align: -webkit-center;
  color: #2c3e50;
}

.page-home{
	padding-top: 200px;
	display: flex;
	display: -webkit-flex;
	flex-direction: column;
	width: 100%;
}

.logo{}

.title{
	margin-bottom: 50px;
	font-size: 100px;
}

.input-area{
	flex-direction: column;
	margin-left: 30%;
	margin-right: 30%;
	width: 40%;	
	height: 100px;
}

.input-label{
	width: 100%;
	text-align: left;
	text-align: -webkit-left;
	font-size: x-large;
}

.input-box{
	width: 100%;
	margin-left: 0;
	margin-right: 0;
	margin-top: 10px;
	flex-direction: row;
	
}

.gene{
	width: 85%;
	height: 45px;
	border-radius: 10px 0px 0px 10px;
	border-color: darkgray;
	border-width: thin;
	font-size: 20px;
	margin-top: 0px;
	margin-bottom: 0px;
}

.clear-input{
	width: 14%;
	height: 49.5px;
	border-radius: 0px 10px 10px 0px;
	border-color: darkgray;
	border-width: thin;
	font-size: 20px;
	color: #FFFFFF;
	background-color: rgba(44,62,80,0.8);
	border-color: rgba(44,62,80,0.2);
}

.fixed-area{
	display: flex;
	display: -webkit-flex;
	flex-direction: row;
	margin-left: 30%;
	margin-right: 30%;
	width: 40%;
}

.species{
	text-align: left;
	padding-left: 0;
	width: 50%;
}

.method{
	text-align: left;
	width: 40%;
}

.knock{
	text-align: left;
	width: 10%;
}

.submit-area{
	margin-left: 30%;
	margin-right: 30%;
	width: 40%;
	margin-top: 50px;
	margin-bottom: 50px;
}

.submit-button{
	width: 30%;
	height: 35px;
	font-size: 20px;
	padding-top: 5px;
	margin-left: 35%;
	margin-right: 35%;
	background-color: #2C3E50;
	color: white;
	border-radius: 20px;
	border: none;
}

.alert{
	margin-left: 30%;	margin-right: 30%;	width: 40%;		height: 100px;
	font-size: 10px;
	background-color: #f8d7da;
	padding-top: 20px;
	color: #721c24;
	
}

</style>

