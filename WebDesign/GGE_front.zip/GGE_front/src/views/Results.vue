
<template>
	<div id="app">
		<div class="site-canvas" ref="canvas">
		  <div class="dna">
		    <div class="dna_section" v-for="(dna,i) in sequence">
		      <div class="node top" v-bind:style="{'animation-delay' : -(i * 300) + 'ms' }"></div>
		      <div class="node bottom" v-bind:style="{'animation-delay' : -(i * 300) + 'ms' }"></div>
		    </div>
		  </div>
		</div>
		<div class="dna_text" ref="dna_text">Loading...</div>
		<div class="error" ref="error" v-show="render">
			<div class="error-title">ERROR</div>
			<div class="error-content">
				Can not found the results corresponding to the input batch zone!<br>
				The input must be a no more than 300 bases window around a TSS,<br>
				e.g. chr13:39276927-39277227
			</div>
		</div>
		<div class="page-results">
			<div class="area" v-show="show_results">{{area}}</div>
			<div class="panel" ref="panel"></div>
			<div class="plot-panel" ref="plotPanel"></div>
			<div class="heatMap-panel" ref="heatMapPanel">
				<div class="heatMap-high" ref="heatMapHigh"></div>
				<div class="heatMap-low" ref="heatMapLow"></div>
			</div>
			<div class="download" v-show="show_results">
				<button class="download-button" @click="download">Download Results as .csv</button>
				<a class="hyperLink" :href = "hyperLink">for more details about this page~</a>
			</div>
			<div class="table-area" v-show="show_results">
				<div class="tableFixed"></div>
			</div>
		</div>
	</div>
</template>

<script>
	import * as d3 from 'd3';
	import axios from 'axios';
    export default {
		data() {
			  return {
				  hyperLink: '',
				  render1: false,
				  render2: false,
				  render: false,
				  show_results: false,
				  sequence: [],
				  parsedCSV: '',
				  //area: 'chr11:37719830-37720130',
				  area: '',
				  fileName: '',
				  query: {"isIsoform":false},
				  // cutcoords: [[1, 37719979, 69.05, 23, "+", 0],
				  // [2, 37719982, 64.21, 23, "-", 1], 
				  // [3, 37720099, 52.07, 23, "+", 1], 
				  // [4, 37720015, 65.33, 23, "-", 0], 
				  // [5, 37719808, 51.05, 23, "-", 0], 
				  // [6, 37719993, 57.61, 23, "-", 2], 
				  // [7, 37719944, 79.28, 23, "-", 0], 
				  // [8, 37719947, 62.57, 23, "-", 1], 
				  // [9, 37720091, 61.47, 23, "+", 0], 
				  // [10, 37720116, 48.30, 23, "-", 0], 
				  // [11, 37719909, 38.75, 23, "+", 0]],
				  cutcoords: '',
				  //tss: [37719980],
				  tss: '',
				  //genemin: 37719830, 
				  //genemax: 37720130,
				  genemin: '',
				  genemax: '',
				  w: '',
				  xScale: '',
				  xScale2: '',
				  margin: {
					  top: 20,
					  bottom: 20,
					  left: 20,
					  right: 20
				  },
				  w: '',
				  tierPx: 17,
				  genePx: 30,
				  tiers: '',
				  h: '',
				  iso_h: '',
				  xAxis: '',
				  xAxisGrid: '',
				  maxScaleFactor: '',
				  sExtM: '',
				  zoom: '',
				  svg: '',
				  gX: '',
				  gXgrid: '',
				  colorscale: '',
				  chartBody: '',
				  //batch_coor: [{"chromo": "chr11", "zone": [["chr11", 37719830, 37720130]]}],
				  batch_coor: '',
				  batch_zone_bar: '',
				  textRank: '',
				  focus: '',
				  tssArrow: '',
				  tssTick: '',
				  asc: false,
				  lowHighThreshold: 52.09,
				  high_freq: [0.3, 0.28, 0.35, 0.26, 0.26, 0.25, 0.27, 0.29, 0.36, 0.44, 0.39, 0.5, 0.36, 0.5, 0.38, 0.16, 0.7, 0.19, 0.29, 0.07, 0.18, 0.0, 0.0, 0.22, 0.23, 0.29, 0.2, 0.32, 0.19, 0.21, 0.28, 0.22, 0.18, 0.15, 0.18, 0.13, 0.25, 0.24, 0.06, 0.07, 0.1, 0.15, 0.02, 0.1, 0.0, 0.0, 0.31, 0.25, 0.27, 0.26, 0.2, 0.3, 0.27, 0.23, 0.24, 0.23, 0.31, 0.18, 0.24, 0.05, 0.22, 0.06, 0.03, 0.16, 0.28, 0.9, 0.17, 1.0, 1.0, 0.17, 0.24, 0.1, 0.28, 0.22, 0.26, 0.24, 0.2, 0.19, 0.15, 0.16, 0.13, 0.27, 0.2, 0.15, 0.72, 0.19, 0.55, 0.29, 0.01, 0.55, 0.0, 0.0],
				  low_freq: [0.21, 0.25, 0.23, 0.27, 0.27, 0.24, 0.26, 0.28, 0.22, 0.2, 0.18, 0.12, 0.2, 0.19, 0.19, 0.15, 0.08, 0.1, 0.13, 0.24, 0.29, 0.0, 0.0, 0.32, 0.35, 0.28, 0.4, 0.37, 0.39, 0.38, 0.35, 0.36, 0.39, 0.45, 0.49, 0.44, 0.34, 0.34, 0.58, 0.81, 0.84, 0.81, 0.46, 0.53, 0.0, 0.0, 0.15, 0.22, 0.17, 0.15, 0.17, 0.17, 0.17, 0.19, 0.18, 0.22, 0.17, 0.18, 0.19, 0.26, 0.18, 0.15, 0.06, 0.04, 0.04, 0.04, 0.1, 1.0, 1.0, 0.32, 0.18, 0.33, 0.17, 0.19, 0.2, 0.2, 0.18, 0.23, 0.19, 0.19, 0.21, 0.17, 0.22, 0.29, 0.12, 0.05, 0.03, 0.01, 0.26, 0.08, 0.0, 0.0],
				  
			  }
			  
		},
		computed: {
		},
		filters: {},
		created() {},
		mounted() {
			this.sequence = new Array(Math.round(document.body.clientWidth/70));
			this.drawWholePage();
			
			
			
			

			
		},
        methods: {
			drawSeqOnHeatMap(seq, heatArea){
				//console.log("draw");
				const width = this.$refs.heatMapPanel.offsetWidth / 2;
				const gridSize = 30;
				const padding = {
					top: 20,
					bottom: 20,
					left: (width - 24*gridSize)/2,
					right: (width - 24*gridSize)/2
				};
				//console.log(d3.select(heatArea));
				const baseList = ["A", "T", "G", "C"];
				const points = d3.select(heatArea).selectAll(".pointsHeatMap")
					.data(seq.split(""))
					.enter()
					.append("circle")
					.attr("cx", (_, i) => i*gridSize + padding.left + gridSize/2)
					.attr("cy", (d, i) => baseList.indexOf(d) * gridSize + 80 + gridSize/2)
					.attr("r", gridSize/8)
					.attr("class", "heatMap-points")
					.attr("ref", "heatPoints")
					.style("fill", "rgb(110,99,105)");
			},
			drawHeatMap(){
				const width = this.$refs.heatMapPanel.offsetWidth / 2;
				const gridSize = 30;
				const padding = {
					top: 20,
					bottom: 20,
					left: (width - 24*gridSize)/2,
					right: (width - 24*gridSize)/2
				};
				
				//console.log(width);
				const svg1 = d3.select(".heatMap-high")
					.append("svg:svg")
					.attr("class","svg-high")
					.attr("width", width)
					.attr("height", "200px");
					
				const title1 = svg1.selectAll(".heatMapTitle")
					.data(["High Efficiency"])
					.enter()
					.append("text")
					.text((d) => d)
					.attr("x", width/2)
					.attr("y", 40)
					.attr("font-size",30)
					.attr("fill","rgb(157,112,114)")
					.style("text-anchor", "middle");
					
					
				const baseLabels1 = svg1.selectAll(".baseLabel")
					.data(["A","T","G","C"])
					.enter() 
					.append("text")
					.text((d) => d)
					.attr("x", padding.left)
					.attr("y", (_, i) => i * gridSize + 80)
					.style("text-anchor", "end")
					.attr("transform", "translate(-6," + gridSize / 1.5 + ")")
					.attr("class", (d) =>"base-"+d);
				
				const posLabels1 = svg1.selectAll(".posLabel")
					.data([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23])
					.enter().append("text")
					.text((d) => d)
					.attr("x", (_, i) => i * gridSize + padding.left)
					.attr("y", 75)
					.style("text-anchor", "middle")
					.attr("transform", "translate(" + gridSize / 2 + ", -6)")
					.attr("class", (d) => "pos_index"+d);
				
				const heatMap1 = svg1.selectAll(".freqHigh")
					.data(this.high_freq)
					.enter()
					.append("rect")
					.attr("x", (_, i) => (i % 23)*gridSize + padding.left)
					.attr("y", (_, i) => parseInt(i / 23)*gridSize + 80)
					.attr("rx", 0)
					.attr("ry", 0)
					.attr("class", "high-rect")
					.attr("width", gridSize)
					.attr("height", gridSize)
					.style("fill", (d) => "rgba(157,112,114,"+ d +")");
					
					
				const svg2 = d3.select(".heatMap-low")
					.append("svg:svg")
					.attr("class","svg-low")
					.attr("width", width)
					.attr("height", "200px");
					
				const title2 = svg2.selectAll(".heatMapTitle")
					.data(["Low Efficiency"])
					.enter()
					.append("text")
					.text((d) => d)
					.attr("x", width/2)
					.attr("y", 40)
					.attr("font-size",30)
					.attr("fill","rgb(44,62,80)")
					.style("text-anchor", "middle");
						
				const baseLabels2 = svg2.selectAll(".baseLabel")
					.data(["A","T","G","C"])
					.enter()
					.append("text")
					.text((d) => d)
					.attr("x", padding.left)
					.attr("y", (_, i) => i * gridSize + 80)
					.style("text-anchor", "end")
					.attr("transform", "translate(-6," + gridSize / 1.5 + ")")
					.attr("class", (d) =>"base-"+d);
				
				const posLabels2 = svg2.selectAll(".posLabel")
					.data([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23])
					.enter().append("text")
					.text((d) => d)
					.attr("x", (_, i) => i * gridSize + padding.left)
					.attr("y", 75)
					.style("text-anchor", "middle")
					.attr("transform", "translate(" + gridSize / 2 + ", -6)")
					.attr("class", (d) => "pos_index"+d);
				
				const heatMap2 = svg2.selectAll(".freqLow")
					.data(this.low_freq)
					.enter()
					.append("rect")
					.attr("x", (_, i) => (i % 23)*gridSize + padding.left)
					.attr("y", (_, i) => parseInt(i / 23)*gridSize + 80)
					.attr("rx", 0)
					.attr("ry", 0)
					.attr("class", "low-rect")
					.attr("width", gridSize)
					.attr("height", gridSize)
					.style("fill", (d) => "rgba(44,62,80,"+ d +")");
					
					
			},
			drawPlot(){
				const width = this.$refs.plotPanel.offsetWidth;
				const padding = {
					top: 20,
					bottom: 30,
					left: 20,
					right: 50
				};
				const num = this.parsedCSV.length;
				//console.log(num);
				const svg = d3.select(".plot-panel")
					.append("svg:svg")
					.attr("width", width + this.margin.left + this.margin.right)
					.attr("height", "150px");
				// const xScale = d3.scaleLinear()
				//     .domain(d3.extent(this.parsedCSV, (d) => parseInt(d['Rank'])))
				//     .range([0, width - padding.left - padding.right]);
				
				const xScale = d3.scaleLinear()
				    .domain([1,num])
				    .range([0, width - padding.left - padding.right]);
				
				var yScale = d3.scaleLinear()
					.domain(d3.extent(this.parsedCSV,(d) => parseInt(d["GC content (%)"])))
				    .range([150 - padding.top - padding.bottom, 0]);
					
				const xAxis = d3.axisBottom(xScale).ticks(num);
				const yAxis = d3.axisLeft(yScale).ticks(5);
				svg.append('g')
				    .attr('class', 'plot-xAxis')
				    .attr('transform', 'translate(' + (padding.left) + ',' + (150 - padding.top) + ')')
				    .call(xAxis);
				svg.append('g')
				    .attr('class', 'plot-yAxis')
					.attr('transform', 'translate(' + (padding.left) + ',' + (padding.bottom) + ')')
				    .call(yAxis);

				svg.selectAll('.plot-xLabel')
					.data(["Rank"])
					.enter()
					.append("text")
					.text((d) => d)
					.attr("x", xScale(num)+10)
					.attr("y", 5)
					.attr("font-size", 15)
					.attr('transform', 'translate(' + (padding.left) + ',' + (150 - padding.top) + ')');
				
				svg.selectAll('.plot-yLabel')
					.data(["GC content (%)"])
					.enter()
					.append("text")
					.text((d) => d)
					.attr("x", -padding.left)
					.attr("y", 30)
					.attr("font-size", 15)
					.attr('transform', 'translate(' + (padding.left) + ',0)');
			
				
				var psCSV = this.parsedCSV;
				const ss = svg
				    .selectAll('.line')
				    .data(this.parsedCSV)
				    .enter()
				    .append('line')
				    .attr('style', 'stroke:rgba(161,185,189,0.75)')
				    .attr('curve', 'curve')
				    .attr('transform', 'translate(' + (padding.left) + ',' + (padding.bottom) + ')')
				    .attr('x1', (_, i) => {
				      return xScale(i+1);
				    })
				    .attr('y1', (_,i) => {
				      return yScale(psCSV[i]['GC content (%)']);
				    })
				    .attr('x2', (_, i) => {
				      return i + 1 < psCSV.length
				        ? xScale(i+2)
				        : xScale(i+1);
				    })
				    .attr('y2', (_, i) => {
				      return i + 1 < psCSV.length ? yScale(psCSV[i+1]["GC content (%)"]) : yScale(psCSV[i]["GC content (%)"]);
				    });
				const line = d3.line().curve(d3.curveCatmullRom.alpha(0));
				
				const color_list = ['rgb(161,185,189)','rgb(177,173,126)','rgb(135,144,153)','rgb(186,182,197)','rgb(172,146,169)'];
				
				svg.selectAll('circle')
					.data(this.parsedCSV)
					.enter()
					.append('circle')
					.attr('transform', 'translate(' + (padding.left) + ',' + (padding.bottom) + ')')
					.attr('cx', function(d) {
						return xScale(d.Rank);
					})
					.attr('cy', function(d) {
						return yScale(d["GC content (%)"]);
					})
					.attr('r', 5)
					.attr('fill', function(d, i) {
						return color_list[i%5];
					});
				  
				  
			},
			sleep(ms) {
			  return new Promise(resolve => setTimeout(resolve, ms));
			},
			async drawWholePage() {
							
				//console.log(this.$route.query.gene);
				if (this.$route.query.gene) {
				
				this.area = this.$route.query.gene;
				
				
				this.fileName = this.area.replace(':', '_');
				let thisLoc = window.location.href.split('?')[0].replace("results","introduction");
				this.hyperLink = thisLoc;
				
				await this.loadCSV();
				await this.getCutcoords();
				
				//await this.sleep(5000);
				//console.log(this.render1);
				//console.log(this.cutcoords);
				
				
				if (this.render1 && this.render2)
				{
				this.$refs.canvas.remove();
				this.$refs.dna_text.remove();
				this.show_results = true;
				
				const table = d3.select('.tableFixed')
					.append('table')
					.attr("class", "wholeTable");
				const thead = table.append('thead');
				const tbody = table.append('tbody');
				//console.log(this.parsedCSV);
				thead.append('tr')
					.selectAll('th')
					.data(this.parsedCSV.columns).enter()
					.append('th')
					.text(function(column) { return column; });
				that = this;
				const rows = tbody.selectAll('tr')
					.data(this.parsedCSV)
					.enter()
					.append('tr')
					.attr('id', (d) => 'guide' + d['Rank'])
					.on("mouseover", function(d) {
						d3.select("#guide-line" + d['Rank']).attr("stroke-width", 15);
						d3.select("body").style("cursor", "pointer");
						d3.select("#guide" + d['Rank']).selectAll("td").style("background-color", "rgba(186,182,197,0.3)");
						that.focus.style("display", null).select(".zoombox").attr("x1", that.xScale(that.cutcoords[parseInt(d['Rank'])-1][1] - 1)).attr("x2", that.xScale(that.cutcoords[parseInt(d['Rank'])-1][1] + that.cutcoords[parseInt(d['Rank'])-1][3] - 1));
						that.drawSeqOnHeatMap(d['Target sequence'], (d['Efficiency']>=that.lowHighThreshold)?".svg-high":".svg-low");
					})
					.on("mouseout", function(d) {
						d3.select("body").style("cursor", "move");
						d3.select("#guide-line" + d['Rank']).attr("stroke-width", 10);
						d3.select("#guide" + d['Rank']).selectAll("td").style("background-color", "white");
						var ele = document.getElementsByClassName("heatMap-points");
						for(var i = ele.length - 1; i >= 0; i--) { 
						  ele[i].parentNode.removeChild(ele[i]); 
						}

					});
					
				var that = this; 
				//let asc = false;
				thead.selectAll('th').on("click", function(d) {
					var sorting = that.asc ? d3.ascending : d3.descending;
					var sign = that.asc ? -1 : 1;
					that.asc = !that.asc;
					rows.sort(function(a, b) {
						let sort = null;
						if (/\d/.test(a[d])) { //only numbers
						const aN = a[d].replace(/\D/g, "");
						const bN = b[d].replace(/\D/g, "");
						sort = sign * (aN - bN);
						} else {
						sort = sorting(b[d], a[d]);
						}
						return sort;
					});
				});
				

				
				const cells = rows.selectAll('td')
					.data(function(row) {
						return that.parsedCSV.columns.map(function(column) {
							let val = row[column];
							return { column: column, value: val };
						});
					})
					.enter()
					.append('td')
					.html(function(d) { return "<code>"+d.value+"</code>";});


				
				
				
				this.w = this.$refs.panel.offsetWidth - this.margin.left - this.margin.right;	
				this.tiers = d3.max(this.cutcoords, function(d) {return d[d.length - 1];});
				this.h = (Math.max(this.tiers, 5) * this.tierPx) + 10 + 30 - this.margin.top - this.margin.bottom;
				this.iso_h = (Math.max(this.tiers, 5) * this.tierPx) + 10 - this.margin.top;
				this.xScale = d3.scaleLinear().domain([this.genemin, this.genemax]).range([0, this.w]);
				this.xScale2 = d3.scaleLinear().domain([this.genemin, this.genemax]).range([0, this.w]);
				this.xAxis = d3.axisBottom(this.xScale).ticks(10);
				this.xAxisGrid = d3.axisBottom(this.xScale).ticks(10).tickSize(-this.h, 0, 0).tickFormat("");
				this.maxScaleFactor = this.w / Math.abs(this.genemin - this.genemax);
				this.sExtM = this.w / Math.abs(this.xScale(100) - this.xScale(1));
				this.zoom = d3.zoom().scaleExtent([1, this.sExtM]).on("zoom", this.zoomed);
				
				
				this.svg = this.createPicZone();
				this.gX = this.drawNumLabelBelow();
				this.gXgrid = this.createGrid();
				
				this.clip = this.createClip();
				
				//create chartBody
				this.focus = this.drawFocusShadow();
				this.chartBody = this.svg.append("g").attr("clip-path", "url(#clip)");
				this.createMarker();
				this.colorscale = d3.scaleThreshold().domain([42.97,59.85]).range(["rgba(44,62,80,1)","rgba(44,62,80,0.75)","rgba(44,62,80,0.5)"]);
				this.drawMainBarchart();
				this.batch_zone_bar = this.drawBatchZone();
				this.textRank = this.drawRankLabel();
				this.drawLegend();
				var tssArea = this.svg.append("g").attr("class", "tssArea");
				this.tssArrow = this.drawTssArrow(tssArea);
				this.tssTick = this.drawTssTick(tssArea);
				this.$refs.panel.style.borderStyle = "dashed";
				this.$refs.panel.style.borderColor = "#2c3e50";
				this.$refs.panel.style.borderWidth = "1px";
				
				
				
				this.drawPlot();
				this.drawHeatMap();
				
				}
				else
				{
					this.$refs.canvas.remove();
					this.$refs.dna_text.remove();
				}
				
				}
				else {
					this.$refs.canvas.remove();
					this.$refs.dna_text.remove();
					this.render=true;
				}
				
				
				
			},
			async getCutcoords() {
				let thisLoc = window.location.href.split('?')[0].replace("results","picture");
				//console.log(thisLoc + '/'+ this.fileName);
				await axios.post(thisLoc + '/'+ this.fileName)
				.then((res)=>{
				    if (res.status===200){
						if (res.data.genemax==='') {
							this.render1 = false;
							this.render = true;
						}
						else
						{
							this.render1 = true;
							this.cutcoords = res.data.cutcoords;
							this.tss = res.data.tss;
							this.genemin = res.data.genemin;
							this.genemax = res.data.genemax;
							this.batch_coor = res.data.batch_coor;
						}
					} else{
						this.render = true;
					}
				})
			},
			async loadCSV() {
				let thisLoc = window.location.href.split('?')[0];
				//console.log(thisLoc + '/' + this.fileName +'.csv');
				try {
					this.parsedCSV = await d3.csv(thisLoc + '/' + this.fileName +'.csv');
				}
				catch (error) {
					this.render = true;
					this.$refs.canvas.remove();
					this.$refs.dna_text.remove();
				}
				if(this.parsedCSV.length>0){
					this.render2 = true;
				}
				else {
					this.render = true;
				}
			},
			zoomed() {
				var that = this;
				//console.log("lalala");
				if (d3.event.sourceEvent && d3.event.sourceEvent.type === "brush") return; // ignore zoom-by-brush
				this.xScale.domain(d3.event.transform.rescaleX(this.xScale2).domain());
				this.gX.call(this.xAxis);
				this.gXgrid.call(this.xAxisGrid);
				this.svg.selectAll(".cutsite")
					.attr("x1", (d) => this.xScale(d[1] - 1))
					.attr("x2", (d) => this.xScale(d[1] + d[3] - 1));
				this.batch_zone_bar.attr("x1", (d) => this.xScale(d[1])).attr("x2", (d) => this.xScale(d[2]));
				this.textRank.attr("x", (d) => this.xScale(d[1] + (d[3] / 2)));
				this.tssArrow.attr("points", (d) => {
						var arr=[that.xScale(d)+0.5,",",that.h-5," ",that.xScale(d)-2.5,",",that.h+5," ",that.xScale(d)+3.5,",",that.h+5];
						return arr.join("");
					});
				this.tssTick.attr("x1", (d) => this.xScale(d)+0.5).attr("x2", (d) => this.xScale(d)+0.5).attr("y1", "0").attr("y2", this.h);
				//exons.attr("x1", (d) => xScale(d[1])).attr("x2", (d) => xScale(d[2]));
				//intron1.attr("x1", (d) => xScale(d[2])).attr("x2", (d) => xScale(d[2] + d[3] / 2));
				//intron2.attr("x1", (d) => xScale(d[2] + d[3])).attr("x2", (d) => xScale(d[2] + d[3] / 2));
				//atg.attr("x1", (d) => xScale(d.loc - 0.5)).attr("x2", (d) => xScale(d.loc + 0.5));
			},
			createPicZone() {
				var svg = d3.select(".panel")
					.append("svg:svg")
					.attr("width", this.w + this.margin.left + this.margin.right)
					.attr("height", this.h + this.margin.top + this.margin.bottom)
					.call(this.zoom)
					.append("svg:g")
					.attr("transform", "translate(" + this.margin.left + "," + this.margin.top + ")");
				//console.log("hhh");
				return svg;
			},
			drawNumLabelBelow() {
				var gX = this.svg.append("svg:g")
					.attr("class", "x axis")
					.attr("transform", "translate(0, " + this.h + ")")
					.call(this.xAxis);
				return gX;
			},
			createGrid() {
				var gXgrid = this.svg.append("g")
					.attr("class", "x grid")
					.attr("transform", "translate(0," + this.h + ")")
					.call(this.xAxisGrid);
				return gXgrid;
			},
			createClip() {
				var clip = this.svg.append("svg:clipPath")
					.attr("id", "clip")
					.append("svg:rect")
					.attr("x", 0)
					.attr("y", 0)
					.attr("width", this.w)
					.attr("height", this.h);
				return clip;
			},
			createMarker() {
				this.svg.append("defs")
					.append("marker")
					.data(this.cutcoords)
					.attr("id", "forward_arrow")
					.attr("refX", 0)
					.attr("refY", 0.5)
					.attr("markerWidth", 6)
					.attr("markerHeight", 1)
					.attr("stroke-width", 0)
					.attr("orient", "auto")
					.append("path")
					.attr("d", "M 0,0 V 1 L0.5,0.5 Z")
					.style("stroke", "rgba(61,49,91,1)")
					.style("fill", "rgba(61,49,91,1)");
					
				this.svg.append("defs")
					.append("marker")
					.data(this.cutcoords)
					.attr("id", "reverse_arrow")
					.attr("refX", 0.5)
					.attr("refY", 0.5)
					.attr("markerWidth", 6)
					.attr("markerHeight", 2)
					.attr("stroke-width", 0)
					.attr("orient", "auto")
					.append("path")
					.attr("d", "M 0.5,0 V 1 L0,0.5 Z")
					.style("stroke", "rgba(61,49,91,1)")
					.style("fill", "rgba(61,49,91,1)");
			},
			drawMainBarchart() {
				var that = this;
				this.chartBody.selectAll("cutsite")
					.data(this.cutcoords)
					.enter().append("line")
					.attr("marker-start", (d) => {
						let arr = (!this.query.isIsoform & d[4] == '-');
						return (arr) ? 'url(#reverse_arrow)' : 'none';
					})
					.attr("marker-end", (d) => {
						let arr = (!this.query.isIsoform & d[4] == '+');
						return arr ? 'url(#forward_arrow)' : 'none';
						})
					.attr("class", "cutsite")
					.attr("id", (d) => "guide-line"+d[0])
					.attr("x1", (d) => this.xScale(d[1] - 1))
					.attr("x2", (d) => this.xScale(d[1] + d[3] - 1))
					.attr("y1", (d) => this.iso_h - 25 - d[d.length - 1] * 12)
					.attr("y2", (d) => this.iso_h - 25 - d[d.length - 1] * 12)
					.attr("stroke-width", 10)
					.attr("height", 10)
					.attr("stroke", (d) => this.colorscale(d[2]))
					.on("mouseover", function(d) {
						d3.select(this).attr("stroke-width", 15)
						d3.select("body").style("cursor", "pointer");
						that.focus.style("display", null).select(".zoombox")
							.attr("x1", that.xScale(d[1] - 1)).attr("x2", that.xScale(d[1] + d[3] - 1));
						d3.select("#guide" + d[0]).selectAll("td").style("background-color", "rgba(186,182,197,0.3)");
					})
					.on("mouseout", function(d) {
						d3.select("body").style("cursor", "move");
						d3.select(this).attr("stroke-width", 10);
						that.focus.style("display", "none");
						d3.select("#guide" + d[0]).selectAll("td").style("background-color", "white");
					});
			},
			drawBatchZone() {
				var barBlow= this.chartBody.selectAll("barBlow")
					.data(this.batch_coor)
					.enter()
					.append("g");
				var batch = barBlow.selectAll("zone")
					.data((d, i) => {
						d.zone.map((x) => x.push(i));
						return d.zone;
					})
					.enter()
					.append("line")
					.attr("x1", (d) => this.xScale(d[1]))
					.attr("x2", (d) => this.xScale(d[2]))
					.attr("y1", (d) => this.iso_h)
					.attr("y2", (d) => this.iso_h)
					.attr("stroke", "rgba(110,99,105,1)")
					.attr("stroke-width", 8);
				return batch;
			},
			drawRankLabel() {
				var textRank = this.chartBody.selectAll("cutsitetext")
					.data(this.cutcoords)
					.enter()
					.append("text")
					.attr("class", "cutsitetext")
					.text((d) => d[0])
					.attr("font-size", "10px").attr("stroke", "rgba(240,228,206,1)")
					.attr("x", (d) => this.xScale(d[1] - 1 + (d[3] / 2)))
					.attr("y", (d) => { return this.iso_h - 10 - 12 - d[d.length - 1] * 12;});
				return textRank;
			},
			drawLegend() {
				var legend = this.chartBody.append("g");
				legend.append("rect").
					attr("x", 0).attr("y", 0)
					.attr("width", 100).attr("height", 55)
					.attr("stroke", "gray").attr("stroke-width", 0.5)
					.attr("fill", "white").style("z-index", 100000);
				legend.append("text").text("5' -->  3'")
					.attr("x", 32).attr("y", 13)
					.attr("font-family", "arial")
					.attr("font-size", "12px")
					.attr("fill", "rgba(57,45,99,1)").attr("z-index", 100000);
				legend.append("line").attr("x1", 7).attr("x2", 37)
					.attr("y1", 22).attr("y2", 22)
					.attr("stroke-width", 8).attr("stroke", "rgba(110,99,105,1)")
					.attr("z-index", 100000);
				legend.append("text").text("Batch Zone")
					.attr("x", 42).attr("y", 25).attr("font-family", "arial")
					.attr("font-size", "10px").attr("fill", "black").attr("z-index", 100000);
				legend.append("line").attr("x1", 7).attr("x2", 17)
					.attr("y1", 35).attr("y2", 35).attr("stroke-width", 10)
					.attr("stroke", "rgba(44,62,80,1)").attr("z-index", 100000);
				legend.append("line").attr("x1", 17).attr("x2", 27)
					.attr("y1", 35).attr("y2", 35).attr("stroke-width", 10)
					.attr("stroke", "rgba(44,62,80,0.75)").attr("z-index", 100000);
				legend.append("line").attr("x1", 27).attr("x2", 37)
					.attr("y1", 35).attr("y2", 35).attr("stroke-width", 10)
					.attr("stroke", "rgba(44,62,80,0.5)").attr("z-index", 100000);
				legend.append("text").text("Target")
					.attr("x", 42).attr("y", 38).attr("font-family", "arial")
					.attr("font-size", "10px").attr("fill", "black").attr("z-index", 100000);
				legend.append("polygon").attr("class", "tssArrow").attr("fill", "rgba(148,60,58,1)")
					.attr("points", "21,42 18,50 24,50");
				legend.append("text").text("TSS")
					.attr("x", 42).attr("y", 50).attr("font-family", "arial")
					.attr("font-size", "10px").attr("fill", "black").attr("z-index", 100000);
				legend.append("text").text("Double click to zoom out.")
					.attr("x", this.w - 120).attr("y", 10).attr("font-family", "arial").attr("font-size", "10px")
					.attr("fill", "black").attr("z-index", 100000);
				legend.append("text").text("Drag to move left and right.")
					.attr("x", this.w - 120).attr("y", 20).attr("font-family", "arial").attr("font-size", "10px")
					.attr("fill", "black").attr("z-index", 100000);
				legend.append("text").text(this.batch_coor[0].chromo).attr("stroke","#FFFFFF").attr("stroke-width",0.5)
					.attr("x", 0).attr("y", this.h-5).attr("font-family", "arial").attr("font-size", "15px")
					.attr("font-weight", "bold").attr("fill", "rgba(146,80,82,1)").attr("z-index", 100000);
			},
			drawFocusShadow() {
				var focus = this.svg.append("g").attr("class", "focus").style("display", "none");
				focus.append("line")
					.attr("class", "zoombox")
					.attr("x1", 100)
					.attr("x2", 100)
					.attr("y1", this.iso_h - 13)
					.attr("y2", this.iso_h - 13)
					.attr("stroke", "DarkGray")
					.attr("stroke-width", 10)
					.attr("stroke-opacity", 0.3);
				return focus;
			},
			drawTssArrow(tssArea) {
				var that = this;
				var tssArrow = tssArea.selectAll("tss")
					.data(this.tss).enter()
					.append("polygon")
					.attr("class", "tssArrow")				
					.attr("points", (d) => {
						var arr=[that.xScale(d)+0.5,",",that.h-5," ",that.xScale(d)-2.5,",",that.h+5," ",that.xScale(d)+3.5,",",that.h+5];
						//console.log(arr.join(""));
						return arr.join("");
					})
					.attr("fill", "rgba(148,60,58,1)");
				return tssArrow;
			},
			drawTssTick(tssArea) {
				var tssTick = tssArea.selectAll("tss")
					.data(this.tss).enter()
					.append("line")
					.attr("class", "tssGrid")
					.attr("x1", (d) => this.xScale(d)+0.5).attr("x2", (d) => this.xScale(d)+0.5)
					.attr("y1", "0").attr("y2", this.h)
					.attr("stroke", "rgba(148,60,58,1)").attr("stroke-width",1)
					.attr("stroke-dasharray", "3 2");
				return tssTick;
			},
			download() {
				let thisLoc = window.location.href.split('?')[0];
				//console.log(thisLoc);
				window.open(thisLoc+'/'+this.fileName+'.csv', '_blank');
			}
			
			
        
        }
	
    };
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 0px;
  width: 100%;
}

.page-results {
	margin-top: 0px;
	display: flex;
	display: -webkit-flex;
	flex-direction: column;
	width: 98%;
	padding-left: 1%;
	padding-right: 1%;
}

.error{
	margin-left: 30%;	margin-right: 30%;	width: 40%;		height: 200px;
	font-size: 20px;
	background-color: #f8d7da;
	padding-top: 10px;
	color: #721c24;	
}

.error-title {
	font-size: 55px;
	font-weight: bold;
	margin-top: 20px;
	margin-bottom: 20px;
}

.area {
	text-align: left;
	font-size: 35px;
	padding-top: 50px;
	padding-bottom: 30px;
	color: rgba(157,129,137,1);
	cursor: default;
}

.panel {
	width: 100%;
	/* border-style: dashed; */
	/* border-color: #2c3e50; */
	/* border-width: 1px; */
	padding-top: 0;
}

.heatMap-panel {
	width: 100%;
	display: flex;
	flex-direction: row;
	height: 200px;
}

.heatMap-high {
	width: 50%;
}

.heatMap-low {
	width: 50%;
}

.plot-panel {
	width: 100%;
	height: 150px;
	padding-top: 0;
}

.grid path {
    stroke-width: 0;
}

.x.grid .tick {
    stroke: #2c3e50;
	opacity: 0.15;
}

.axis path,
.axis line {
    fill: none;
    stroke: rgba(44,62,80,0.1);
}

.x.axis path {
    display: none;
}

.download {
	padding-top: 20px;
	padding-bottom: 20px;
	height: 30px;
	width: 100%;
	flex-direction: row;
	cursor: default;
}

.download-button {
	margin-left: 0px;
	width: 250px;
	position: absolute;
	left: 1.25%;
	height: 30px;
	font-size: 16px;
	background-color: rgba(44,62,80,0.8);
	color: white;
	border-radius: 5px;
	border: none;
}

.hyperLink{
	float: right;
	display: fixed;
	right: 150px;
}

.table-area {
	width: 100%;
}

.tableFixed {
	width: 100%;
	padding-left: 0px;
	padding-right: 0px;
	cursor: default;
}

table {
	width: 100%;
	border-collapse: collapse;
	margin: 0 auto;
	text-align: center;
}
table tbody {
	display:block;
	width: 100%;
	height:400px;
	overflow-y: scroll;
	overflow-x: hidden;
	-webkit-overflow-scrolling: touch;
}


table thead {
	display:table;
	width: calc( 100% - 5px);
	table-layout:fixed;
}

table td, table th {
	border: 1px solid rgba(135,144,153,0.2);
	color: #666;
	height: 38px;
}

table thead th {
	background-color: rgba(161,185,189,0.75);
}

table tbody tr {
    display:table;
    width:100%;
    table-layout:fixed;
}

table tbody tr:hover{
    background-color: rgba(161,185,189,0.25);}

table tbody tr td:nth-child(1){
	width: 5%;
}

table thead tr th:nth-child(1){
	width: 5%;
}

table tbody tr td:nth-child(2){
	width: 20%;
}

table thead tr th:nth-child(2){
	width: 20%;
}

table tbody tr td:nth-child(3){
	width: 20%;
}

table thead tr th:nth-child(3){
	width: 20%;
}

table tbody tr td:nth-child(11){
	width: 10%;
}

table thead tr th:nth-child(11){
	width: 10%;
}

::-webkit-scrollbar{
	width:5px;
	height:10px;
}

::-webkit-scrollbar-thumb{
	background-color: rgba(161,185,189,0.75);
	border-radius:6px;
}

::-webkit-scrollbar-track{
	background-color: ragba(255,255,255,0);
	border-radius:6px;
}




.site-canvas {
  position:relative;
}
.dna {
  position:fixed;
  top:50%;
  left:50%;
  -webkit-transform:translate(-50%,-50%);
          transform:translate(-50%,-50%);
  width:90%;
  height:250px;
  text-align:center;
  overflow:hidden;
}
.dna_section {
  position:relative;
  margin:0 0px;
  width:50px;
  height:250px;
  display:inline-block;
}
.dna_text {
	position:absolute;
	margin-top:750px;
	right: 350px;
	font-size: 80px;
	text-align: right;
	color: rgba(44,62,80,0.8);
	width:500px;
	height:250px;
	display:inline-block;
}
.dna_section .node {
  position:absolute;
  top:0;
  left:0;
  width:50px;
  height:50px;
  border-radius:100%;
  background:rgba(157,111,113,1);
  -webkit-animation:4s topNode ease-in-out infinite;
          animation:4s topNode ease-in-out infinite;
}
@-webkit-keyframes topNode {
  0% {-webkit-transform:scale(0.5);transform:scale(0.5);top:0;z-index:10;opacity:0.75;}
  25% {-webkit-transform:scale(1);transform:scale(1);opacity:1;}
  50% {-webkit-transform:scale(0.5);transform:scale(0.5);top:200px;z-index:0;opacity:0.75;}
  75% {-webkit-transform:scale(0.25);transform:scale(0.25);opacity:0.5;}
  100% {-webkit-transform:scale(0.5);transform:scale(0.5);top:0;opacity:0.75;}
}
@keyframes topNode {
  0% {-webkit-transform:scale(0.5);transform:scale(0.5);top:0;z-index:10;opacity:0.75;}
  25% {-webkit-transform:scale(1);transform:scale(1);opacity:1;}
  50% {-webkit-transform:scale(0.5);transform:scale(0.5);top:200px;z-index:0;opacity:0.75;}
  75% {-webkit-transform:scale(0.25);transform:scale(0.25);opacity:0.5;}
  100% {-webkit-transform:scale(0.5);transform:scale(0.5);top:0;opacity:0.75;}
}
.dna_section .node.bottom {
  top:auto;
  bottom:0;
  background:rgba(129,146,156,1);
  -webkit-animation:4s bottomNode ease-in-out infinite;
          animation:4s bottomNode ease-in-out infinite;
}
@-webkit-keyframes bottomNode {
  0% {-webkit-transform:scale(0.5);transform:scale(0.5);bottom:0; opacity:0.75;}
  25% {-webkit-transform:scale(0.25);transform:scale(0.25);opacity:0.5;}
  50% {-webkit-transform:scale(0.5);transform:scale(0.5);bottom:200px; opacity:0.75;}
  75% {-webkit-transform:scale(1);transform:scale(1); opacity:1;}
  100% {-webkit-transform:scale(0.5);transform:scale(0.5);bottom:0; opacity:0.75;}
}
@keyframes bottomNode {
  0% {-webkit-transform:scale(0.5);transform:scale(0.5);bottom:0; opacity:0.75;}
  25% {-webkit-transform:scale(0.25);transform:scale(0.25);opacity:0.5;}
  50% {-webkit-transform:scale(0.5);transform:scale(0.5);bottom:200px; opacity:0.75;}
  75% {-webkit-transform:scale(1);transform:scale(1); opacity:1;}
  100% {-webkit-transform:scale(0.5);transform:scale(0.5);bottom:0; opacity:0.75;}
}

</style>
