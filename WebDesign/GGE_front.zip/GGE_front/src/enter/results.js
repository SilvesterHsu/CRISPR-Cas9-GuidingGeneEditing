import Vue from 'vue'
import Results from '../views/Results.vue'
import router from '@/router'
import store from '@/store'
import VueRouter from 'vue-router'

Vue.use(VueRouter);
let resultsRouter = new VueRouter({mode: 'history', routes: router.results});
Vue.config.productionTip = false
new Vue({
	router:resultsRouter,
	store,
	render: function(h) {return h(Results)}
}).$mount('#app')