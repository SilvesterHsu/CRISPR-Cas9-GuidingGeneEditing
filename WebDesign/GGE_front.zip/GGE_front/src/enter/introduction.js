import Vue from 'vue'
import Introduction from '../views/Introduction.vue'
import router from '@/router'
import store from '@/store'
import VueRouter from 'vue-router'

Vue.use(VueRouter);
let introductionRouter = new VueRouter({mode: 'history', routes: router.introduction});
Vue.config.productionTip = false
new Vue({
	router:introductionRouter,
	store,
	render: function(h) {return h(Introduction)}
}).$mount('#app')