import Vue from 'vue'
import Home from '../views/Home.vue'
import router from '@/router'
import store from '@/store'
import VueRouter from 'vue-router'

Vue.use(VueRouter);
let homeRouter = new VueRouter({mode: 'history', routes: router.home});
Vue.config.productionTip = false
new Vue({
	router:homeRouter,
	store,
	render: function(h) {return h(Home)}
}).$mount('#app')