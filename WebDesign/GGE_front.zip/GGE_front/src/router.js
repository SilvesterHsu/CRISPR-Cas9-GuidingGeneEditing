export default{
	home: [
		{
			path: '/home',
			name: 'Home',
			components: require('@/views/Home.vue')
		}
	],
	results: [
		{
			path: '/results/:gene',
			name: 'Results',
			components: require('@/views/Results.vue'),
		}
	],
	introduction: [
		{
			path: '/introduction',
			name: 'Introduction',
			components: require('@/views/Introduction.vue'),
		}
	],
}