const webpack = require('webpack')
module.exports = {
	assetsDir: "static",
	pages:{
		home:{
			entry: 'src/enter/home.js',
			// template: 'public/Home.html',
			filename: 'home.html',
			title: 'Home',
		},
		results:{
			entry:'src/enter/results.js',
			filename:'results.html',
			title: 'Results of Query',
		},
		introduction: {
			entry:'src/enter/introduction.js',
			filename:'introduction.html',
			title: 'Introduction',
		}
    },
	configureWebpack: {
		plugins: [
			new webpack.ProvidePlugin({
				$: "jquery",
				jQuery: "jquery",
				"windows.jQuery": "jquery"
			})
		]
	}
}